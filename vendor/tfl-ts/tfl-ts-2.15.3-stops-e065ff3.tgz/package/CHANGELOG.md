# Changelog

## 2.16.0 — unreleased

### Static stop index: `tfl-ts/meta/stops`

One bundled index of every station and London bus stop (id, name, painted stop letter, `towards`, position, lines, modes, hub), so a search box can answer synchronously and add TfL's live results afterwards.

- `tfl-ts/meta/stops` (cjs, esm, types): `STOP_INDEX`, `searchStops`, `mergeLiveResults`, `findHighlightedIndex`, `createStopIndex`, the folding helpers and the types. `searchStops` folds case, accents, `King's`/`Kings`, `&`/`and`, `St`/`Saint` and abbreviations, understands `kings cross E` / `(Stop E)` / `stop E`, and ranks exact < prefix < word-prefix < contains, stations above bus stops, then distance to an optional `near`, then A–Z. `mergeLiveResults` keeps every instant row and its position, enriches matching rows in place (same id, or hub and member through `STATION_HUBS`), appends live-only hits below, and a second merge of the same payload returns the same array.
- `tfl-ts/meta/stops/build`: `buildStopIndex({ appKey, stations, fetch })` rebuilds the index from `/StopPoint/Mode/bus` pages (and route sequences or hub payloads when needed). It paces under 500 requests a minute, retries with backoff, and never logs the key or a URL carrying it. `pnpm run generate -- --only=stops` writes `src/generated/stops/StopIndex.ts`; `pnpm run check` validates it.
- The 456 stations that tfl-components kept in `data/geography/all-stations.json` now live in the same index (`script/data/all-stations.geojson` is the seed).
- The main entry, `tfl-ts/meta` and `tfl-ts/ui` are unchanged and do not include the index. A Jest test walks their import graph, and `script/bundleCeilings.json` now fails the bundle check if the index reaches them, with a 400 KB gzip ceiling on `tfl-ts/meta/stops` itself.
- `busStopSearch.ts` now exports `readStopLetter`, `normalizeStopLetter`, `readAdditionalProperty` and `usableText` for the builder. The main entry does not re-export them.

## 2.15.3 — 2026-10-27

### MCP tool annotations, empty resources and prompts

Every MCP tool now has a `title` and annotations: `readOnlyHint: true`, `destructiveHint: false`, `idempotentHint: true`. `openWorldHint` is `false` for `get_supported_modes`, `resolve_line_id` and `docs`, which read bundled data, and `true` for `resolve_stop_id`, `get_line_status`, `get_arrivals` and `plan_journey`, which call TfL. Clients that auto-approve read-only tools can now tell these apart from tools that change state.

`resources/list`, `resources/templates/list` and `prompts/list` returned `-32601 Method not found`. `initialize` now declares `resources` and `prompts`, and those three methods return empty arrays. `resources/read` returns `-32002` and `prompts/get` returns `-32602`, since nothing is listed. MCP `serverInfo.version` is `1.4.1`.

A new Jest test spawns the compiled `tfl mcp` over stdio with no `TFL_APP_KEY` and checks the handshake, tool list, empty lists, an offline call and the missing-key error. Like the other compiled-binary tests, it needs `pnpm run build` before `pnpm test`.

The repo also has a `Dockerfile` and `glama.json` that run `tfl mcp` in a container, with `TFL_APP_KEY` optional. Neither ships in the npm package.

## 2.15.2 — 2026-10-16

### Official MCP Registry manifest

`package.json` now sets `mcpName` to `io.github.ghcpuman902/tfl-ts`. Root `server.json` follows the current registry schema (`2025-12-11`): npm package `tfl-ts`, stdio transport, positional argument `mcp`.

The npm bin is `tfl` (`dist/cjs/bin/tfl.js`, compiled from `src/bin/tfl.ts`). `npx -y tfl-ts mcp` runs that binary with the `mcp` subcommand, which calls `startTflMcpServer()` and speaks JSON-RPC on stdin/stdout. Live tools need `TFL_APP_KEY`. `TFL_MCP_MIN_INTERVAL_MS` overrides the default 250ms gap between outbound TfL requests. `TFL_APP_ID` is still ignored. See [docs/mcp.md](docs/mcp.md).

## 2.15.1 — 2026-10-16

Docs: README hero, comparison table; homepage now https://tfl.manglekuo.com

## 2.15.0 — 2026-09-16

### Offline `tfl check`, JSON `tfl list`, tighter public types, use-case evals

An agent can type-check `'Central'` and only learn it is wrong after a live call. `tfl check --line` / `--mode` now validates against bundled `Lines` and `Modes` with no `TflClient` and no key. Display-case `'Central'` exits 1 and suggests `central`. The same helpers are on `tfl-ts/meta` (`checkLineIds`, `checkModeNames`).

`tfl list` prints a JSON array of `{ tag, method, httpMethod, path }` by default. `--json` is honoured. `--text` restores the old `tag.method -> GET /path` lines. Scripts that grepped the arrow form need `--text`.

Public extra-field bags (`LineInfo`, stop-point, road, cabwise, air quality, accident stats) and `TflValidationError.value` are `unknown` instead of `any`. `TflErrorHandler.handleApiError` takes `unknown`. Callers that read extra keys need a narrow. MCP `docs` now advertises `anyOf` per operation (`read` needs `id`, `find` needs `query`, `grep` needs `pattern`). `serverInfo.version` is `1.4.0`.

`pnpm run eval` is a second runner, not a Jest gate. Offline scenarios always run. `--live` adds tube status, Oxford Circus arrivals, and an Oxford Circus–Bond Street journey, scored as rates over repeated trials. Empty arrivals and 429s skip. Default exit is 0. `--fail-under` is opt-in. A green eval does not prove a coding agent will choose these calls. See [docs/design/evals.md](docs/design/evals.md).

## 2.14.0 — 2026-08-28

### Docs catalogue root, CLI exit codes, MCP tool errors

`tfl docs cat CLAUDE.md` looked for `dist/CLAUDE.md` after compile because `packageRoot` was `join(__dirname, '..')`. In source that is the repo root; in `dist/cjs/docs.js` it is `dist/`. Jest imported `src/docs.ts`, so the suite stayed green while `npx tfl-ts docs cat` and MCP `docs` `read` failed with "reinstall". The reader now walks up to the `package.json` whose `name` is `tfl-ts`, skipping `dist/cjs` and `dist/esm` type-only manifests. A compiled-binary test runs `dist/cjs/bin/tfl.js docs cat CLAUDE.md`.

`tfl` still exits 0 on success and non-zero on failure. The non-zero values are now specific: 1 error (including docs find/grep misses), 2 usage, 3 missing `TFL_APP_KEY`, 4 missing shipped file. `tfl raw line.notAMethod` is resolved against `ENDPOINTS` before constructing `TflClient`, so a typo no longer demands a key. Scripts that only check `exit !== 0` are unchanged. Scripts that compared `exit === 1` for every failure need to treat 2–4 as failure too.

MCP `serverInfo.version` is `1.3.0`. Live-tool errors use the same `{ code, message, fix }` JSON as `docs`. `get_arrivals` with a missing `stopPointId` still says `"stopPointId" must be a non-empty string.` in `message`. `get_line_status` advertises `anyOf: [{ required: ["lineIds"] }, { required: ["modes"] }]`. Agents that treated live error text as a non-JSON string should `JSON.parse` it.

## 2.13.1 — 2026-08-28

### Native Node ESM can load the package

2.13.0 emitted ESM with extensionless relative imports. Node does not guess `.js`, so `import 'tfl-ts'` under native ESM (`tsx --test`, `node --input-type=module`) threw `ERR_UNSUPPORTED_DIR_IMPORT`. CJS `require('tfl-ts')` and bundlers still worked, which is why Jest in this repo did not catch it.

The `RawClient` file was `generated/raw.js` next to the per-tag directory `generated/raw/`. Node treated `from './generated/raw'` as a directory import. The facade is now `generated/rawClient.js`. Build rewrites `dist/esm` specifiers to `./foo.js` or `./foo/index.js`, adds `with { type: 'json' }` on JSON imports, and uses `createRequire(import.meta.url)` for station sequences.

### 2.11 `dist/` specifiers still resolve

2.13.0's `exports` map blocked every `tfl-ts/dist/…` subpath (`ERR_PACKAGE_PATH_NOT_EXPORTED`). 2.11 had no `exports` field, so `import { Lines } from 'tfl-ts/dist/generated/meta/Line.js'` worked. Blocking that in a minor is a break.

Those specifiers are restored as aliases onto `dist/cjs` / `dist/esm`. `tfl-ts/dist/generated/raw.js` points at `rawClient`. They are deprecated, same idea as `tfl-ts/utils/ui`. New code can use `tfl-ts/ui` and `tfl-ts/meta` (`Lines` is on `/meta`). Existing 2.11 imports do not have to change until a major.

## 2.13.0 — 2026-08-28

### Tree-shakeable entrypoints and lazy wrappers

Importing UI helpers or station topology from `'tfl-ts'` used to evaluate the whole CommonJS barrel: every wrapper, all 84 raw methods, station sequences, hubs, and the line catalogue. A Client Component that only needed line colours paid for that graph (esbuild minify+gzip **77,845 bytes**).

The package now ships ESM and CJS, marks `sideEffects: false`, and adds `tfl-ts/ui` and `tfl-ts/meta`. `TflClient` still uses `client.line.getStatus()`; wrappers and `client.raw.<tag>` are created on first access. Station sequences are not loaded for `getStatus()`. `tfl-ts/utils/ui` remains as a deprecated alias.

Measured with the same esbuild flags as 2.12 (see [docs/design/2.13-bundle.md](docs/design/2.13-bundle.md)):

- Status board helpers via `tfl-ts/ui`: **3,560 bytes gzip** (no sequences, no `RawClient`, no `TFL_APP_KEY`). Same helpers via `'tfl-ts'`: 77,845 → **34,824**.
- Topology via `tfl-ts/meta`: **39,218**. Hubs + `resolveArrivalsStopId` via `tfl-ts/meta`: **24,591**.
- `import TflClient`: 77,780 → **47,655**. That path still statically includes every wrapper module. Use `/ui` and `/meta` in the browser.

`new TflClient()` no longer constructs Journey. `client.raw.travelTime` is not allocated until that getter runs.

Accepted: dual CJS/ESM copies in mixed graphs; `Object.keys(client)` omits lazy modules; importing `RawClient` still parses every tag file. 2.11 `tfl-ts/dist/…` specifiers stay as deprecated aliases (see 2.13.1).

## 2.12.0 — 2026-08-28

### `tfl docs` and MCP `docs` — one offline catalogue

`npx tfl-ts docs ls|cat|find|grep` reads Markdown already shipped in the npm tarball (including `README.md`, `AGENTS.md`, `CLAUDE.md`, `docs/agent.md`, `docs/mcp.md`, and `docs/design/agent-friendly-cli.md`) without a repo checkout or network access. `find` ranks id, title, and audience first, then searches document bodies, so `tfl docs find caching` resolves. Empty find/grep results and unknown top-level commands exit non-zero.

The local MCP server adds a read-only `docs` tool (`list` / `read` / `find` / `grep`) over the same `DOC_MANIFEST`. `read` and `grep` are paginated. No API key. Structured errors carry `code`, `message`, and `fix`. MCP `serverInfo.version` is `1.2.0`.

`AGENTS.md` is a compact self-contained quick start for tools that load that filename, not a pointer to `CLAUDE.md`.

Fixed CLI argument dispatch: `tfl <command>` no longer routes through `util.parseArgs`'s strict option validation, which previously threw `Unknown option '--ids'` for the documented usage (`tfl raw line.get --ids central`). Each subcommand now parses its own arguments; `tfl list --tag <tag>` is unaffected.

## 2.11.0 — 2026-08-23

### Lift bus-stop Direction fields off additionalProperties

`Towards` and `CompassPoint` are the documented Direction keys on `GET /StopPoint/Meta/Categories`, not first-class StopPoint fields. `normalizeStopPoint` / `normalizeStopPoints` copy them onto the stop as `towards`, `compassPoint`, and `compassBearingDegrees` (clockwise from north), and fill `smsCode` from the first-class field or bag `SmsCode`. Facility / accessibility keys stay in `additionalProperties`.

`client.stopPoint.get` and `getByGeoPoint` apply this. `client.raw.stopPoint.*` is unchanged.

`GET /StopPoint/{490G…}` of a cluster that sits under a rail interchange (`490G000803` at Charing Cross, `490G000565` Hammersmith Bus Station) returns the `HUB*` node, not the cluster. A standalone cluster (`490G000804`) returns itself with stand children. Arrivals on any `490G` id are an empty array — poll the `/^490\d/` children.

`compassPoint` is the stop flag. Do not use Prediction `bearing` (vehicle heading 0–359) as the flag direction. When TfL cannot cleanse a painted letter it copies `->N` into `indicator` and `stopLetter`; those arrows are a compass fallback. A painted letter `W` is Stop W, not west — CompassPoint on Walthamstow Stop W is `N`.

### Parse additional-property strings

`parseAdditionalPropertyValue` turns a bag `value` into `null` / `boolean` / `number` / `date` / `text`. TfL still sends strings (`"true"`, `"yes"`, `""`, `"null"`, ISO, unix ms). The bag is unchanged; this is a read helper.

### Bus name search expands 490G hubs

`stopPoint.searchBusStops(query)` is the passenger-shaped bus search. TfL's `StopPoint/Search` often returns two boarding `490…` stops plus `490G…` area hubs (e.g. `"Trafalgar Sq"`). This method expands up to three named hubs, merges boarding hits, and keeps name matches. Google-style `"Rookery Road (Stop Y)"` pins that letter first. Five-digit SMS codes still resolve via `getBySms`.

`stopPoint.search()` is unchanged. Pure helpers (`isBoardableBusStopId`, `busSearchNameMatches`, `resolveBusNameSearchHits`, …) are exported for apps that already orchestrate fetches. MCP `resolve_stop_id` with `modes: ["bus"]` uses the expanded search.

## 2.10.0 — 2026-08-17

### River bus colours, line snapshot, and pier traps

Live river-bus lines are `rb1`, `rb4`, `rb6`, and `woolwich-ferry`. The static `Lines` snapshot no longer lists withdrawn `rb2` (that id 404s). `getLineColor` maps those four ids to London River Services blue (`#039BE5`, PMS 299). Withdrawn `rb2` still falls back to the default grey.

`LINE_STATION_SEQUENCES` now includes river-bus pier order (FerryPort ids). River piers are **not** in `STATION_HUBS`: poll the `NaptanFerryPort` (`930G…`) for arrivals, never a berth (`9300…`). `GET /StopPoint/Mode/river-bus` returns an empty list — discover piers with `line.getStopPoints`, `stopPoint.search({ modes: ['river-bus'] })`, or `getByGeoPoint({ stoptypes: ['NaptanFerryPort'] })`. River predictions send a blank `towards`; use `getNormalizedArrivals()` / `destinationName`. Live `river-tour` lines may be none. URA river stream is still deferred.

## 2.9.0 — 2026-08-15

### Treat literal `"null"` towards as empty

TfL sometimes sends `towards: "null"` on bus terminus predictions (Liverpool Street) instead of omitting the field or sending `""`. `resolveArrivalDestination` already fell through a blank `towards` to `destinationName`. A literal `"null"` or `"undefined"` now does the same, so `getNormalizedArrivals()` shows "Liverpool Street, Station" instead of the word null. `getArrivals()` and `client.raw.*` stay unchanged.

## 2.8.0 — 2026-08-15

### Shared-track arrival identity

TfL's Arrivals API assigns `lineId` per station, not per physical train. On Circle / Hammersmith & City / Metropolitan shared track (Baker Street ↔ Aldgate), the same `vehicleId` is `circle` at Victoria and `hammersmith-city` at Liverpool Street in one poll. `tripId` is null for tube.

`getSharedTrackSegments(lineIds)` classifies stations from `LINE_STATION_SEQUENCES` as exclusive to one of those lines or shared, and returns `linesByStation` (which of the given lines serve each stop). `resolveSharedTrackIdentity` / `withSharedTrackIdentity` tag a prediction with additive `sharedTrackIdentity` when the vehicle also appears at an exclusive-segment station (`canonicalLineId`) or is seen on two or more of the given lines with no exclusive evidence (`ambiguous` + `rawLineIds`, for a multi-line chip). Raw `lineId` / `lineName` stay as TfL sent them. Single-line rows with no exclusive hit stay untagged. Rows whose `lineId` is outside the given set are never tagged. TfL reuses `vehicleId` across lines, so a Central train can share an id with a Circle train.

`line.getArrivals({ lineIds })` now accepts an omitted `stopPointId` and calls network-wide `GET /Line/{ids}/Arrivals` (live Unified API; not in the OpenAPI snapshot).

### Line status ranking uses the current row, not every row

TfL attaches more than one `lineStatuses` row to a line. On a Saturday, Waterloo & City is `Service Closed` (20, `RealTime`, `isNow: true`) plus a standing `Planned Closure` (4, `Information`, `isNow: false`) that describes weekday hours. `sortLinesBySeverityAndOrder` used `Math.min` across every row, so the stale 4 beat Jubilee's live `Severe Delays` (6). `getLineStatusSummary` and the MCP `get_line_status` tool reported "Planned Closure" for a line that is fully shut.

The helpers now pick the operative rows first: `RealTime`, then `PlannedWork` / `Information` whose validity window overlaps `now`, then standing rows with no window. Rank is by `getStatusKind` (`incident` → `plannedWork` → `closed` → `info` → `good`), then TfL's number inside a kind, then `LINE_ORDER`. Severity 20 is scheduled closure, not an unplanned Closed (1). `isNow` is not a clock. It tracks `category === 'RealTime'`, which is why a London Trams part closure can be in force today with `isNow: false`.

`getWorstCurrentStatus` / `getCurrentLineStatuses` / `getStatusKind` / `isScheduledClosure` are the new reads. `sortLinesBySeverityAndOrder` no longer mutates its input, and a missing `statusSeverity` is no longer treated as Special Service (0). `hasNightService` is deprecated: 20 means closed, not "has a night service". `getSeverityCategory(18)` is `good` (`No Issues`); it used to match the substring "issues" and come back `minor`.

Boards that want a separate "not running" section should partition after these helpers. That layout is product policy, not something tfl-ts encodes per line or per hour.

## 2.7.0 — 2026-08-15

### Station hubs and arrival field normalisation

`STATION_HUBS` is a committed static snapshot of interchange membership: each physical station's `hubNaptanCode`, sibling StopPoint ids, and the StopPoint that actually carries arrivals for each line (`lineMemberIds`). Import it with no credentials. `resolveArrivalsStopId(hub, lineId)` picks the correct sibling for a poll — Liverpool Street Underground (`940GZZLULVT`) and rail (`910GLIVST`) resolve to one `HUBLST` entry, with Central on the tube id and Elizabeth line on the rail id. It returns `undefined` for a line the hub doesn't carry, not the interchange id itself: polling `HUBLST` directly returns zero arrivals from TfL, so falling back to it would look valid and quietly return nothing.

`normalizeArrival` / `normalizeArrivals` add a cleaned `destination` (empty `towards` falls through to `destinationName`) and `platform` (`compassBound`, label, `isUnknown` for TfL's literal "Platform Unknown"). `client.stopPoint.getNormalizedArrivals()` is `getArrivals()` plus that mapper. `getArrivals()` and `client.raw.*` stay unchanged.

TfL's raw StopPoint hierarchy lists a hub as one of its own members and mixes bus route numbers into the same `lineGroup` data used to build `lineMemberIds` — Waterloo's hub node mapped bus routes `1`, `11`, `n381` to bus stop ATCO codes alongside `bakerloo`, `jubilee`, and `south-western-railway`. The generator now drops the hub's own aggregate node from `members` and keeps only `lineMemberIds` entries that resolve to a real member or the hub id, so bus routes can't leak in.

Third-party National Rail operators (Southeastern, South Western Railway, c2c, Greater Anglia, and similar) appear in `lineMemberIds` for topology, since they're genuinely part of a station's TfL-registered hierarchy, but TfL's Arrivals API has no live predictions for them. Polling `south-western-railway`'s member id at Waterloo, or a National Rail-only station entirely outside the TfL network (Epsom, Reigate), returns an empty array rather than an error. Only tube, DLR, tram, Overground, and Elizabeth line return live predictions.

Regenerate hubs with `pnpm run generate -- --only=station-hubs`. `pnpm run check` validates the committed snapshot offline.

## 2.6.2 — 2026-08-12

### Primary key is the only required credential

The TfL portal gives you a Primary key and a Secondary key. Either one is `app_key`. `TflClient` requires `appKey` / `TFL_APP_KEY`. Passing `appId` still forwards it on the request.

## 2.6.1 — 2026-08-11

### Packaging, docs, and maintain tooling

- Ship `ERROR.md` in the npm tarball so linked error docs resolve for package consumers.
- Collapse maintain scripts into `generate`, `check`, and `demo` with `--only` / target args; `prepublishOnly` and CI use `pnpm run check`.
- Remove paste-in UI board examples and the local Express playground board; point readers at [tfl-components](https://github.com/ghcpuman902/tfl-components) and the [API explorer](https://tfl.manglekuo.com/docs/explorer).
- Rewrite the README for first-success (v2.6.1 tagline, screenshots above the fold, Node / Next.js / MCP lanes).
- Add GitHub Actions CI on `main` (`build`, `test`, `check`).

No runtime API changes.

## 2.6.0 — 2026-08-10

### Fix BikePoint e-bike / classic bike counts

Live `/BikePoint` payloads expose classic and electric availability as `NbStandardBikes` and `NbEBikes`. Status extraction previously looked up the unprefixed `StandardBikes` / `EBikes` keys, so `standardBikes` and `eBikes` were almost always `0` even when `bikes` was correct (for example Pennington Street showing 13 bikes total but `0` / `0` in the split).

`extractStatus` and `findElectricBikes` now prefer the live `Nb*` keys and still accept the unprefixed names as a fallback. `PROPERTY_KEYS` documents the live keys.

## 2.5.0 — 2026-08-09

### Static station sequences

`LINE_STATION_SEQUENCES` and `client.line.STATION_SEQUENCES` provide station IDs, station names, ordered routes, directions, service types, and branch relationships. The committed topology covers Tube, Elizabeth line, DLR, London Overground, and Tram. Importing `LINE_STATION_SEQUENCES` needs neither TfL credentials nor a live internet connection. The data contains no service status, disruption, validity, or arrival information.

`line.getRouteSequence()` remains the explicitly live API. Consumers can update `tfl-ts` when they want a newer permanent network topology, or call the live method when they need TfL's current response.

The new `generate:station-sequences` command builds the constants from TfL route sequences in memory and validates every included line before replacing the committed file. Empty or malformed responses fail generation and leave the previous snapshot intact. `check:station-sequences` validates the committed snapshot locally without contacting TfL and now runs before publish.

### Fix dated `line.getStatus` 404

TfL's `/Line/{ids}/Status/{startDate}/to/{endDate}` endpoint returns **404** when the same `startDate`/`endDate` values are also sent as query parameters. The generated raw client no longer duplicates path dates into the query string (and the generator skips query params that share names with path params). `client.line.getStatus({ lineIds, dateRange, detail: true })` works again.

### Friendly detailed line status

`line.getDetailedStatus()` requests `detail=true` and returns a compact model with short, stable names. Consumers can use `DetailedLine`, `DetailedLineStatus`, `DetailedDisruption`, `AffectedRoute`, and `AffectedStop` without importing TfL's generated `TflApiPresentationEntities*` types.

The mapper renames common fields such as `statusSeverity` to `severity`, `validityPeriods[].fromDate` to `from`, `closureText` to `closureType`, and route `originationName` to `originName`. Missing TfL arrays become empty arrays, which removes repetitive guards in application code.

`getStatus()` and `client.raw.line.*` still return the exact generated TfL response. `mapDetailedLines()` is exported for callers that already have a detailed raw response.

### README rewrite

The package README leads with install and three short recipes (status, arrivals, journey), then gotchas, module index, and the new APIs. Architecture, agents, and MCP sit below the fold. Contributing commands are separated from the consumer path.

## 2.4.0 — 2026-08-07

### Northern dark-contrast modes

`getLineCssProps` and `getLineDarkReadableStyles` accept `{ darkContrastMode: 'outline' | 'white' }` (default `outline`).

- **outline:** keep brand black; expose `--line-dark-text-stroke` / `--line-dark-paint-order` for outside text stroke, plus existing hard text/box shadow rings as fallback.
- **white:** opt into white fill/text on dark surfaces (`--line-dark-fill` / `--line-dark-text`), clear stroke and shadows; chip labels use `--line-dark-on-fill`.

`--line-color` remains the official brand hex in both modes. Additive CSS vars for lines without poor dark contrast are harmless no-ops.

## 2.3.3 — 2026-07-25

### IDE autocomplete for wrapper inputs

JSDoc `@example` blocks never drove Tab completion, and public options typed as plain `string` / `string[]` gave IntelliSense nothing to suggest — so `modes: ['|']` felt broken even when `ModeName` already existed in the package.

Wrapper inputs now use open unions (`ModeInput`, `LineIdInput`, `ServiceTypeInput` via `AutocompleteString<T>`): known literals complete in the IDE, unknown strings (including bus route numbers) still type-check. Line ID suggestions use named/slug lines only so the list is not flooded with hundreds of bus numbers.

Fixed-shape methods also gain positional overloads alongside the options-object form (`getStopPoints('central')`, `plan(from, to)`, `search(query)`, …). With `typescript.suggest.completeFunctionCalls`, Tab can place real argument placeholders instead of a single opaque `options` bag.

Object-param call sites remain valid; this is additive.

### Journey plan disambiguation (HTTP 300)

Ambiguous `from` / `to` / `via` values make TfL respond with HTTP 300 and a disambiguation body. That path now goes through `TflHttpError` and returns options on `JourneyResult.disambiguation` instead of treating 300 as a failed fetch of a raw `Response`. Covered by unit tests; the journey playground demo prints the option list more consistently.

### `line.get()` requires `lineIds` or `modes`

Calling `line.get()` with no filters hit `/Line/` with an empty id list and came back as a confusing 404. TfL has no unfiltered “all lines” list endpoint. The method now throws `TflValidationError` and tells you to pass `modes` / `lineIds`, or use `LINE_NAMES` / `LINE_INFO` for the static catalogue.

### AccidentStats marked as retiring

TfL’s Unified API tidy-up retires `/AccidentStats/{year}` on 31 July 2026; the feed only ever covered 2005–2019. Module docs and the playground demo say so plainly, probe 2019 as best-effort, and treat upstream failure as expected rather than a broken wrapper.

### Playground demos tolerate flaky TfL endpoints

Live demos for occupancy, place, travelTimes, and line no longer dump stack traces and exit 1 when TfL returns 500/400 on optional calls. They print a short warning and continue so a full demo sweep stays readable.

### Cleaner publish / test output

Realtime poller tests now use the default 30s interval (and matching fake-timer advances) instead of 1s, so they no longer trip the “below recommended TTL” warning. Package scripts chain with `pnpm run` rather than `npm run`, which stops pnpm’s store/registry settings being passed into npm as unknown config during `prepublishOnly`.

## 2.3.2 — 2026-07-25

### Local MCP server

Coding agents often need live TfL data without inventing their own HTTP client. A hosted MCP would share one API key across users and burn rate limits. This release adds a small read-only MCP server inside the package: `tfl mcp` over stdio, using each user's own `TFL_APP_ID` / `TFL_APP_KEY`.

The tool set is intentionally small (`get_supported_modes`, `resolve_line_id`, `resolve_stop_id`, `get_line_status`, `get_arrivals`, `plan_journey`). Tools return compact JSON with a plain-text `summary` field, not raw TfL payloads. Live calls are cached, duplicate in-flight requests are combined, and outbound traffic is spaced (default 250ms; override with `TFL_MCP_MIN_INTERVAL_MS`).

```json
{
  "mcpServers": {
    "tfl-ts": {
      "command": "npx",
      "args": ["-y", "tfl-ts@latest", "mcp"],
      "env": {
        "TFL_APP_ID": "your-app-id",
        "TFL_APP_KEY": "your-app-key"
      }
    }
  }
}
```

Details: [docs/mcp.md](docs/mcp.md).

### Agent-facing docs and examples

TfL mixes stable reference data with live operational data, but the raw API does not draw that line. Agents that treat every question as an HTTP call waste quota and invent wrong IDs.

This release adds:

- [CLAUDE.md](CLAUDE.md) and [.claude/skills/tfl-ts/SKILL.md](.claude/skills/tfl-ts/SKILL.md) for the static-vs-live model, traps, and copy-paste patterns
- [docs/agent.md](docs/agent.md) for module reference, caching TTLs, and Next.js usage
- [examples/](examples/) for library → UI mapping (tube status boards and bus arrivals)
- README pitch clarifying wrappers vs raw, static metadata vs live data, and UI helpers

npm keywords now include `mcp`, `claude-skill`, `ai-agent`, and related terms.

### Playground status and arrivals boards

The local HTML playground (`pnpm run playground`) uses official line colours and bus route chips for `/status` and `/arrivals`, aligned with the examples mapping docs.
