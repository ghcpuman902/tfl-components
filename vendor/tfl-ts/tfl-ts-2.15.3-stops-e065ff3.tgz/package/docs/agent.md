# tfl-ts — Agent Reference

This document is the detailed reference for AI coding agents integrating the **tfl-ts** npm package. For install, first-success examples, and screenshots, see [README.md](../README.md). For quick patterns, see [.claude/skills/tfl-ts/SKILL.md](../.claude/skills/tfl-ts/SKILL.md). For repo maintenance (clone only, not in `tfl docs`), see [LLM_context.md](../LLM_context.md).

## Package overview

```typescript
import TflClient from 'tfl-ts';

const client = new TflClient(); // requires TFL_APP_KEY
```

**Architecture (v2):**

```
client.line / stopPoint / journey / …   ← friendly wrappers (use these)
client.raw.<tag>.<method>()             ← escape hatch (all 84 REST endpoints)
client.realtime.pollArrivals()          ← REST polling helper
```

## Static metadata vs live API

### Static (bundled — no network, no credentials for reads)

These are available synchronously on the client instance after construction:

| Property | Module | Purpose |
|----------|--------|---------|
| `LINE_NAMES` | `line` | Map of line ID → display name |
| `LINE_INFO` | `line` | Full line metadata per ID |
| `STATION_SEQUENCES` | `line` | Station IDs, names, ordered routes, and branch relationships |
| `STATION_HUBS` | package export | Interchange membership, sibling StopPoint ids, and per-line arrivals ids |
| `MODE_NAMES` | `line`, `stopPoint`, `journey`, `mode` | Valid transport mode strings |
| `MODE_METADATA` | `line` | `isTflService`, `isFarePaying`, etc. |
| `SEVERITY_DESCRIPTIONS` | `line` | All severity label strings |
| `SEVERITY_BY_MODE` | `line` | Severity levels per mode |
| `SERVICE_TYPES` | `line`, `stopPoint` | `'Regular'`, `'Night'` |
| `DISRUPTION_CATEGORIES` | `line`, `stopPoint` | Disruption type strings |
| `STOP_POINT_CATEGORIES` | `stopPoint` | Stop category enums |
| `STOP_POINT_TYPES` | `stopPoint` | Stop type enums |
| `LINE_IDS` | package export | Mode-grouped line name → ID maps |
| `STOP_INDEX` | `tfl-ts/meta/stops` only | Every station and London bus stop, with letter, towards, position, lines, modes. Opt-in subpath; see [Stop index](#stop-index-tfl-tsmetastops) |

**Use static metadata for:** input validation, dropdowns, display labels, station diagrams, severity styling, mode filtering — anything that does not need current operational state. Import `LINE_STATION_SEQUENCES` from `tfl-ts/meta` when credentials are unavailable. The same data is still on `client.line.STATION_SEQUENCES` (loaded on first access). Client Components should import colours from `tfl-ts/ui`.

### Live (runtime TfL REST API)

Any method that returns a `Promise` hits the network. Key live endpoints:

| Method | Module | Typical use | Suggested cache TTL |
|--------|--------|-------------|---------------------|
| `getStatus()` | `line` | Exact TfL line status response | 30–60s |
| `getDetailedStatus()` | `line` | Friendly periods, closures, affected routes and stops | 30–60s |
| `getRouteSequence()` | `line` | Current TfL route and branch response | 1h+ |
| `getArrivals()` | `line`, `stopPoint`, `mode` | Countdown boards (raw TfL predictions) | 10–15s |
| `getNormalizedArrivals()` | `stopPoint` | Same fetch, plus cleaned destination and platform | 10–15s |
| `search()` | `stopPoint`, `line`, `search`, `place` | Resolve IDs from names | 1h–24h |
| `get()` | `stopPoint`, `line` | Stop/line details | 1h+ |
| `plan()` | `journey` | Route options | 2–5min |
| `getDisruptions()` | `line`, `road` | Active disruptions | 30–60s |
| `pollArrivals()` | `realtime` | Polling helper | 10–15s interval |

**Avoid:** calling `line.get()` to list all lines when `LINE_INFO` already has the data. Avoid re-searching the same stop on every page load — cache the resolved ID.

## Module reference (14 modules)

### `line` — Lines, routes, status, arrivals

```typescript
// Static
client.line.LINE_NAMES['central'];        // "Central"
'id' in client.line.LINE_NAMES;           // validate
client.line.STATION_SEQUENCES.central;     // bundled topology

// Live
await client.line.getStatus({ modes: ['tube'] });
await client.line.getStatus({ lineIds: ['central', 'victoria'] });
await client.line.getDetailedStatus({
  lineIds: ['bakerloo'],
  dateRange: { startDate: '2026-08-08', endDate: '2026-08-10' },
});
await client.line.getArrivals({ lineIds: ['central'], stopPointId: '940GZZLUOXC' });
await client.line.getRouteSequence({ lineId: 'central', direction: 'outbound' });
await client.line.search({ query: 'victoria' });
await client.line.get({ modes: ['tube'] });
```

### `stopPoint` — Stops, arrivals, timetables

```typescript
// Static
client.stopPoint.MODE_NAMES;
client.stopPoint.STOP_POINT_TYPES;

// Live
await client.stopPoint.search({ query: 'Oxford Circus', modes: ['tube'] });
await client.stopPoint.get({ stopPointIds: ['940GZZLUOXC'] });
// Bus flags: towards, compassPoint, compassBearingDegrees, smsCode are lifted
await client.stopPoint.getArrivals({ stopPointIds: ['940GZZLUOXC'] });
await client.stopPoint.getNormalizedArrivals({ stopPointIds: ['940GZZLUOXC'] });

import { STATION_HUBS, resolveArrivalsStopId, normalizeArrival } from 'tfl-ts/meta';
const hub = STATION_HUBS['940GZZLULVT'];
const elizabethStop = hub && resolveArrivalsStopId(hub, 'elizabeth');
// resolveArrivalsStopId returns undefined for a line the hub doesn't carry —
// never the hub id itself, which returns zero arrivals when polled directly.
// Third-party National Rail operators (southeastern, south-western-railway, …)
// are mapped for topology but TfL has no live predictions for them; only
// tube, DLR, tram, Overground, Elizabeth line, bus, and river-bus return live arrivals.
// River-bus: poll NaptanFerryPort (930G…), not berths (9300…) or StopPoint/Mode/river-bus.

// Nearby stops by GPS (truncate coords to ~3 decimal places in UI to avoid mobile jitter re-fetching)
const stops = await client.stopPoint.getByGeoPoint({
  lat: 51.508,
  lon: -0.065,
  radius: 400,
  modes: ['bus'],
  stoptypes: ['NaptanPublicBusCoachTram'],
});
```

**Stop ID pattern:** always search → cache ID → use ID for subsequent calls.

Bus stops: search by 5-digit NaPTAN code (e.g. `'51800'`) with `modes: ['bus']`.

### `journey` — Journey planning

```typescript
await client.journey.plan({
  from: '940GZZLUOXC',
  to: '940GZZLUBND',
  mode: ['tube', 'bus', 'walking'],
});
```

- `from` / `to` accept stop IDs, postcodes, or lat/lon strings per TfL API.
- Check `result.disambiguation` — status 300 means multiple matches; present options and re-plan.
- Helpers: `generateNaturalInstruction()`, `getModeIcon()`, `simplifyJourneyResult()`.

### `mode` — Transport mode arrivals

```typescript
await client.mode.getArrivals({ mode: 'tube', stopPointId: '940GZZLUOXC' });
```

### `search` — Global search

```typescript
await client.search.search({ query: 'Oxford Circus' });
```

### `place` — Places and geocoding

```typescript
await client.place.search({ name: 'Bank', placeTypes: ['StopPoint'] });
```

### `road` — Road traffic and disruptions

```typescript
// Static
client.road.ROAD_CATEGORIES;
client.road.SEVERITY_DESCRIPTIONS;

// Live
await client.road.getDisruptions();
```

### `bikePoint` — Santander Cycles

```typescript
await client.bikePoint.getAll();
await client.bikePoint.search({ query: 'Hyde Park' });
```

### `vehicle` — Vehicle-specific arrivals

```typescript
await client.vehicle.getArrivals({ vehicleIds: ['LX58CFV'] });
```

### `occupancy` — Car park occupancy

```typescript
await client.occupancy.getAllCarParks();
```

### `travelTimes` — Travel time overlay maps

```typescript
await client.travelTimes.getOverlay({ z: 12, mapCenterLat: 51.5074, /* … */ });
```

### `cabwise` — Taxi/minicab search

```typescript
await client.cabwise.search({ latitude: 51.5074, longitude: -0.1278 });
```

### Deprecated — avoid in new code

- `accidentStats` — deprecated
- `airQuality` — deprecated

## ID resolution patterns

### Line IDs

```typescript
const validateLineIds = (ids: string[]): string[] => {
  const valid = ids.filter((id) => id in client.line.LINE_NAMES);
  const invalid = ids.filter((id) => !(id in client.line.LINE_NAMES));
  if (invalid.length > 0) throw new Error(`Invalid line IDs: ${invalid.join(', ')}`);
  return valid;
};
```

Common IDs: `'central'`, `'victoria'`, `'northern'`, `'elizabeth'`, `'dlr'`, `'overground'`.

Aliases like `'elizabeth-line'` may not be in `LINE_NAMES` — validate before use.

### Stop IDs

```typescript
const resolveStopId = async (name: string, modes: string[]): Promise<string> => {
  const result = await client.stopPoint.search({ query: name, modes });
  const id = result.matches?.[0]?.id;
  if (!id) throw new Error(`No stop found for: ${name}`);
  return id;
};
```

Stop IDs look like `'940GZZLUOXC'` (tube) or `'490003191F'` (bus). They are opaque — never guess.

For bus street names, use `client.stopPoint.searchBusStops(query)` rather than taking `search({ modes: ['bus'] }).matches` as the full stand list. TfL often returns two boarding stops plus `490G…` hubs; `searchBusStops` expands the hubs.

## Error handling

```typescript
import TflClient, {
  TflError,
  TflHttpError,
  TflNetworkError,
  TflTimeoutError,
  TflConfigError,
} from 'tfl-ts';
```

| Error | When | Agent action |
|-------|------|--------------|
| `TflConfigError` | Missing `TFL_APP_KEY` | Set env var or pass `{ appKey }` |
| `TflHttpError` (401/403) | Bad credentials | Check TfL portal keys |
| `TflHttpError` (429) | Rate limit | Back off, increase cache TTL |
| `TflHttpError` (5xx) | TfL server error | Retry (client does this automatically) |
| `TflNetworkError` | Connectivity | Retry with backoff |
| `TflTimeoutError` | Slow response | Increase `timeout` config |

```typescript
const client = new TflClient({
  timeout: 30000,
  maxRetries: 3,
  retryDelay: 1000,
});
```

## Caching guidance

### What to cache and for how long

| Data | TTL | Mechanism |
|------|-----|-----------|
| Line status | 30–60s | `unstable_cache` / Redis / in-memory |
| Arrivals per stop | 10–15s | Short TTL; tag by stop ID |
| Resolved stop IDs | Hours–days | Key: `stop:${normalizedName}:${modes}` |
| Journey results | 2–5min | Key: `journey:${from}:${to}:${time}` |
| Static metadata | Never expire | Already in package |

### What NOT to do

- Poll arrivals every second
- Call `line.get()` on every request when you only need status
- Search for the same stop name on every page view
- Cache arrivals longer than 15 seconds for "live" displays

## Next.js App Router patterns

### Server Component (recommended for status boards)

Minimal list (full branded board: [tfl-components explorer](https://tfl.manglekuo.com/docs/explorer)):

```typescript
// app/status/page.tsx
import TflClient, {
  sortLinesBySeverityAndOrder,
  isNormalService,
  getWorstCurrentStatus,
} from 'tfl-ts';

export const revalidate = 60; // ISR: refresh every 60s

const getTubeStatus = async () => {
  const client = new TflClient();
  const statuses = await client.line.getStatus({
    modes: ['tube', 'elizabeth-line', 'dlr', 'tram', 'overground'],
  });
  return sortLinesBySeverityAndOrder(statuses);
};

export default async function StatusPage() {
  const lines = await getTubeStatus();
  const disrupted = lines.filter((line) => !isNormalService(line.lineStatuses ?? []));
  return (
    <ul>
      {disrupted.map((line) => (
        <li key={line.id}>
          {line.name}: {getWorstCurrentStatus(line.lineStatuses)?.statusSeverityDescription}
        </li>
      ))}
    </ul>
  );
}
```

**Credentials:** set `TFL_APP_KEY` in Vercel environment variables (server-side only). Never expose keys to the client.

### Route Handler with cache

```typescript
// app/api/arrivals/[stopId]/route.ts
import { NextResponse } from 'next/server';
import TflClient from 'tfl-ts';

export const revalidate = 15;

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ stopId: string }> },
) => {
  const { stopId } = await params;
  const client = new TflClient();
  const arrivals = await client.stopPoint.getArrivals({ stopPointIds: [stopId] });
  return NextResponse.json(arrivals);
};
```

### Client Component (live polling)

For countdown boards that update in the browser, expose a Route Handler or Server Action — do not instantiate `TflClient` in client components with embedded credentials.

```typescript
'use client';

import { useEffect, useState } from 'react';

export const ArrivalBoard = ({ stopId }: { stopId: string }) => {
  const [arrivals, setArrivals] = useState([]);

  useEffect(() => {
    const fetchArrivals = async () => {
      const res = await fetch(`/api/arrivals/${stopId}`);
      setArrivals(await res.json());
    };
    fetchArrivals();
    const interval = setInterval(fetchArrivals, 15000);
    return () => clearInterval(interval);
  }, [stopId]);

  // render arrivals…
};
```

## Stop index (`tfl-ts/meta/stops`)

One static index of every station (tube, DLR, Overground, Elizabeth line, tram, hubs) and every London bus stop. No network, no key. It is a separate subpath so nobody pays the bytes unless they import it: the main entry, `tfl-ts/meta` and `tfl-ts/ui` never include it (a Jest test walks the import graph, and `pnpm run check` fails if the marker string reaches those bundles).

```typescript
import { STOP_INDEX, searchStops, mergeLiveResults, findHighlightedIndex } from 'tfl-ts/meta/stops';
```

Each row (`StopRow`): `id` (NaPTAN, or a hub id like `HUBKGX`), `name`, `kind` (`'station'` or `'bus'`), `letter` and `indicator` (the painted letter TfL reports, e.g. `E` / `Stop E`), `towards`, `lat`, `lon`, `lines` (line or route ids), `modes`, `hubId`. The letter is never read from the NaPTAN suffix (`490003087W1` is painted `HA`) and is not a compass point. Station names are the short display label (`Tower Hill`).

### `searchStops(index, query, options?)`

Pure and deterministic. Order: stop-letter pin → match class (exact < prefix < word-prefix < contains < all words) → stations before bus stops → distance to `options.near` → name A–Z → letter → id.

- `searchStops(STOP_INDEX, 'tow')` → Tower Gateway and Tower Hill first.
- `'kings cross'` → the King's Cross & St Pancras hub, then the King's Cross bus stops. With a `near` point they are ordered by distance.
- `'kings cross E'`, `'kings cross stop E'`, `"King's Cross (Stop E)"` pin stop E first and keep the rest. `'stop E'` alone lists only stops painted E.
- A bare trailing letter is also tried as part of the name, so `'oxford c'` still finds Oxford Circus.
- Folding: case, accents, apostrophes, `&`/`and`, `St`/`Saint`/`Street`, `Rd`/`Road`, `Stn`/`Station` and similar. A half-typed `str` still matches `St`.
- Options: `limit` (default 20), `near` (adds `distance` in metres), `kinds`. An empty query returns `[]`, or the nearest rows when `near` is set.

### `mergeLiveResults(instant, live, options?)`

Lays live TfL hits (StopPoint search matches or StopPoint objects) over the instant list so the UI does not jump:

1. Every instant row keeps its `id` and position.
2. A live hit with the same id, or a station hub and one of its members (`STATION_HUBS`), enriches that row in place: missing fields are filled, `lines` and `modes` are unioned, nothing is overwritten and `name` never changes. A bus hit only matches by exact id.
3. Live-only hits are appended below in the order TfL gave them, marked `liveOnly: true`.
4. Merging the same payload again changes nothing and returns the same array, so a UI can skip the re-render.

`findHighlightedIndex(rows, highlightedId, fallback?)` returns the highlighted row's position after a merge. Because rows never move, an id that was in the instant list keeps its index.

### Format, size and refresh

The data is columnar (`tfl-stop-index/1`; see `src/stops/types.ts`): interned names, towards text, line ids and line sets, 5 dp coordinates, rows sorted by id with stations first. `createStopIndex(data)` wraps any `StopIndexData`, for example a copy served from a cache.

Refresh the bundled snapshot with `pnpm run generate -- --only=stops` (needs `TFL_APP_KEY`; about 25 requests: `/StopPoint/Mode/bus` pages plus one fetch per `HUB…`). To refresh a served copy from a server or cron, import the builder from `tfl-ts/meta/stops/build`:

```typescript
import { buildStopIndex, stationSeedsFromIndex } from 'tfl-ts/meta/stops/build';
import { STOP_INDEX, createStopIndex } from 'tfl-ts/meta/stops';

const { data, stats } = await buildStopIndex({
  appKey: process.env.TFL_APP_KEY!, // sent as app_key, never logged
  stations: stationSeedsFromIndex(STOP_INDEX),
});
const fresh = createStopIndex(data); // or JSON.stringify(data) to store it
```

`buildStopIndex` paces itself under 500 requests a minute, retries 408/429/5xx with backoff, and takes an injectable `fetch`. It does not read the environment. If the paged bus listing carries no `lines`, it walks every bus route sequence to fill them (about 1,400 more requests, set `routeSequences: false` to forbid it).

## UI helpers (no API calls)

```typescript
import {
  getLineColor,
  getLineCssProps,
  getLineInlineStyles,
  getLineDarkReadableStyles,
  normalizeLineId,
  getSeverityCategory,
  getSeverityClasses,
  getAccessibleSeverityLabel,
  sortLinesBySeverityAndOrder,
  getLineStatusSummary,
  getWorstCurrentStatus,
  getStatusKind,
  isNormalService,
  isScheduledClosure,
} from 'tfl-ts/ui';
```

Use these for styling status boards — they operate on data already fetched from the API.

A line can carry several `lineStatuses`. `getWorstCurrentStatus` picks the operative row (RealTime first, then PlannedWork / Information whose validity window overlaps now). `getStatusKind` returns `incident` | `plannedWork` | `closed` | `info` | `good`. `sortLinesBySeverityAndOrder` ranks in that order, then by TfL's number inside a kind, then `LINE_ORDER`. It does not mutate the input array.

`validityPeriods[].isNow` is not "affecting passengers now". It tracks `disruption.category === 'RealTime'`. London Trams can show a Part Closure in today's window with `isNow: false`. `validityPeriods[].toDate` is the window end, not when trains resume — weekend engineering often ends at `00:29Z` (01:29 London, end of the traffic day). Overnight-split slices on one row are one possession; do not advertise the first overlapping `toDate`. Current-status helpers do not emit a resume clock. Severity 20 is scheduled closure, not an unplanned Closed (1). Pass `now: fetchedAt` into the helpers from a prerendered board so they do not call `Date.now()` in the shell. Sectioning "not running" away from disruptions is a board decision, not a library one.

**Line colors:** `getLineColor()` returns hex values only (no Tailwind classes). Apply with inline styles or CSS variables — Tailwind cannot see classes inside `node_modules`.

```tsx
const colors = getLineColor(line.id ?? ''); // normalizes elizabeth-line → elizabeth
const cssProps = getLineCssProps(line.id ?? '');

// Color bar — brand hex via --line-color; dark surfaces use --line-dark-fill + outline vars
<div
  style={{ ...cssProps, backgroundColor: 'var(--line-color)', height: 4 }}
  className="dark:bg-[var(--line-dark-fill)] dark:[box-shadow:var(--line-dark-box-shadow)]"
/>

// Card accent
<div style={{ borderLeft: `4px solid ${colors.hex}` }} />

// Line title — default outline (stroke + text-shadow fallback); or darkContrastMode: 'white'
<span
  style={{ color: colors.hex, ...cssProps }}
  className="tfl-dark-line-text"
>
  {line.name}
</span>

// Or: getLineDarkReadableStyles('northern') → outline styles
// getLineDarkReadableStyles('northern', { darkContrastMode: 'white' }) → white fill/text
```

> Default dark contrast is **outline** (Northern stays black with white stroke/rings). Pass `{ darkContrastMode: 'white' }` to opt into white fill/text on dark surfaces.

Or use `getLineInlineStyles` / `getLineCssProps` for common patterns.

## Library → UI examples

Read these on GitHub (or under `node_modules/tfl-ts/examples/` after install). They teach the **data → UI contract**; React/Tailwind optional. tfl-ts has zero runtime UI dependencies.

| Resource | Purpose |
|----------|---------|
| [examples/README.md](../examples/README.md) | Index: tube vs bus mapping rules |
| Live React boards | [tfl.manglekuo.com](https://tfl.manglekuo.com/) |
| Explorer | [tfl.manglekuo.com/docs/explorer](https://tfl.manglekuo.com/docs/explorer) · [ghcpuman902/tfl-components](https://github.com/ghcpuman902/tfl-components) |

**Bus ≠ tube:** do not call `getLineColor` / `getLineCssProps` for bus route numbers.

## Raw client escape hatch

When a wrapper does not exist or you need exact OpenAPI parameter names:

```typescript
// Wrapper:  client.line.getStatus({ lineIds: ['central'] })
// Raw:        client.raw.line.statusByIds({ ids: ['central'], detail: true })

// List all endpoints
import { ENDPOINTS, ENDPOINT_COUNT } from 'tfl-ts';
// Or CLI: npx tfl list --tag journey
// JSON by default; --text for the old tag.method -> lines
```

Raw naming: swagger `Line_StatusByIds` → `client.raw.line.statusByIds()`.

## Realtime

Push/stream (SignalR, URA) is deferred. Use `client.realtime.pollArrivals()` for REST-based polling. See [REALTIME.md](./REALTIME.md).

## Network calls summary

All live methods call `https://api.tfl.gov.uk/` with the `app_key` query parameter. The client:

- Adds auth automatically
- Retries transient failures (up to `maxRetries`)
- Throws typed `TflError` subclasses on failure
- Has zero runtime npm dependencies

## Local MCP server

If the host agent supports MCP, prefer the built-in local server over inventing direct TfL HTTP calls. Run `npx -y tfl-ts@latest mcp` with the user's own credentials.

Tools return compact JSON: a plain-text `summary` plus structured fields (`lines`, `arrivals`, `matches`, `journeys`). Live tools also include `cacheHit` and `fetchedAt`. Use `issuesOnly` on status and `lineIds` on arrivals when you only need a slice of the board. The `docs` tool (`list` / `read` / `find` / `grep`) is offline and needs no API key.

```json
{
  "mcpServers": {
    "tfl-ts": {
      "command": "npx",
      "args": ["-y", "tfl-ts@latest", "mcp"],
      "env": {
        "TFL_APP_KEY": "your-primary-key"
      }
    }
  }
}
```

Full setup, TTLs, and security notes: [mcp.md](./mcp.md). Release notes: [CHANGELOG.md](../CHANGELOG.md).

## Offline doc lookup (`tfl docs` / MCP `docs`)

Every file listed by `tfl docs ls` ships in the npm package and is readable from the CLI or the MCP `docs` tool, without repo access or a network call:

```bash
npx tfl-ts docs ls                 # every bundled doc, with audience
npx tfl-ts docs cat docs/agent.md  # print this file
npx tfl-ts docs find caching       # find the right doc by keyword (id, title, then body)
npx tfl-ts docs grep -i STATION_HUBS
```

MCP equivalent (no API key): `{ "operation": "list" }` / `{ "operation": "find", "query": "caching" }` / `{ "operation": "read", "id": "docs/agent.md" }` / `{ "operation": "grep", "pattern": "STATION_HUBS" }`. Large reads are paginated with `offset` / `limit` / `nextOffset`.

Use this when your context has been compacted mid-session and you no longer have the conventions above loaded — it is faster and more reliable than re-deriving them from raw TfL responses.

## Further reading

- [examples/README.md](../examples/README.md) — library → UI index (tube + bus)
- [mcp.md](./mcp.md) — local MCP setup and rate-limit behavior
- [ERROR.md](../ERROR.md) — full error handling guide
- [MIGRATION-v2.md](./MIGRATION-v2.md) — v1 → v2 migration
- [REALTIME.md](./REALTIME.md) — polling vs push
